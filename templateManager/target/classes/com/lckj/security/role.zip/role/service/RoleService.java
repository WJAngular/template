
package com.lckj.security.role.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lckj.base.BaseConstant;
import com.lckj.core.orm.MybatisMapper;
import com.lckj.core.orm.condition.Condition;
import com.lckj.core.orm.condition.SimpleCondition;
import com.lckj.core.service.AbstractService;
import com.lckj.security.menu.mapper.MenuMapper;
import com.lckj.security.menu.model.MenuVO;
import com.lckj.security.operation.mapper.OperationMapper;
import com.lckj.security.operation.model.OperationVO;
import com.lckj.security.operation.model.RoleROperationVO;
import com.lckj.security.role.mapper.RoleMapper;
import com.lckj.security.role.model.RoleRMenuVO;
import com.lckj.security.role.model.RoleVO;
import com.lckj.security.user.mapper.UserMapper;
import com.lckj.security.user.model.UserRRoleVO;
import com.lckj.security.user.model.UserVO;

/**
 * 角色业务逻辑处理类
 * 
 * @author 黄洪波
 * @since 1.0
 * @version 2015-05-24 黄洪波
 */
@Service
public class RoleService extends AbstractService<RoleVO> {
    
    /** 角色持久化处理接口 */
    @Autowired
    RoleMapper roleMapper;
    
    /** 菜单持久化处理接口 */
    @Autowired
    MenuMapper menuMapper;
    
    /** 用户持久化处理接口 */
    @Autowired
    UserMapper userMapper;
    
    /** 操作持久化处理接口 */
    @Autowired
    OperationMapper operationMapper;
    
    /** 获取Mapper接口 */
    @Override
    protected MybatisMapper<RoleVO> getMapper() {
        return this.roleMapper;
    }
    
    /**
     * 根据角色查询角色对应的菜单信息
     * 
     * @param roleVO 角色信息
     * @return 菜单map集合
     */
    public Map<String, Object> queryRoleMappingMenu(RoleVO roleVO) {
        Map<String, Object> result = new HashMap<String, Object>();
        // 查询角色对应的菜单
        SimpleCondition conditionRole = new SimpleCondition();
        conditionRole.andEqual("roleId", roleVO.getRoleId());
        conditionRole.andEqual("status", BaseConstant.STATUS_ENABLE);
        result.put("current", menuMapper.queryMenuByRole(conditionRole));
        
        // 查询操作权限列表和角色对应的操作权限
        result.put("permissions", operationMapper.list(new Condition()));
        result.put("currentPermissions", operationMapper.queryRolePermissions(roleVO));
        
        // 查询所有的根菜单
        SimpleCondition conditionBase = new SimpleCondition();
        conditionBase.andEqual("parentMenuId", "0");
        conditionBase.andEqual("status", BaseConstant.STATUS_ENABLE);
        
        // 查询所有的子菜单
        SimpleCondition conditionChild = new SimpleCondition();
        conditionChild.andNotEqual("parentMenuId", "0");
        conditionChild.andEqual("status", BaseConstant.STATUS_ENABLE);
        
        // 将对应的子菜单组装到父菜单中
        List<MenuVO> allMenu = compareChildMenuToBaseMenu(menuMapper.list(conditionBase), menuMapper.list(conditionChild));
        result.put("all", allMenu);
        return result;
    }
    
    /**
     * 根据角色查询角色对应的菜单信息
     * 
     * @param roleVO 角色信息
     * @return 菜单map集合
     */
    public List<OperationVO> queryRolePermissions(RoleVO roleVO) {
        return operationMapper.queryRolePermissions(roleVO);
    }
    
    /**
     * 根据角色查询角色对应的菜单信息
     * 
     * @param roleVO 角色信息
     * @return 菜单map集合
     */
    public List<OperationVO> queryPermissions(RoleVO roleVO) {
        return operationMapper.queryPermissions(roleVO);
    }
    
    /**
     * 根据角色查询角色对应的用户信息
     * 
     * @param roleVO 角色信息
     * @return 用户map集合
     */
    public Map<String, Object> queryUserMappingRole(RoleVO roleVO) {
        Map<String, Object> result = new HashMap<String, Object>();
        // 查询角色对应的用户
        SimpleCondition conditionRole = new SimpleCondition();
        conditionRole.andEqual("roleId", roleVO.getRoleId());
        conditionRole.andEqual("status", BaseConstant.STATUS_ENABLE);
        result.put("current", userMapper.queryUserByRole(conditionRole));
        
        // 查询所有的用户
        SimpleCondition condition = new SimpleCondition();
        condition.andEqual("status", BaseConstant.STATUS_ENABLE);
        condition.orderAsc("userId");
        List<UserVO> allUser = userMapper.list(condition);
        result.put("all", allUser);
        return result;
    }
    
    /**
     * 将对应的子菜单组装到父菜单中
     * 
     * @param baseMenu 父菜单
     * @param childMenu 子菜单
     * @return 菜单集合
     */
    private List<MenuVO> compareChildMenuToBaseMenu(List<MenuVO> baseMenu, List<MenuVO> childMenu) {
        // 组装根节点的MAP信息
        Map<Integer, List<MenuVO>> baseMenuMappingChild = new HashMap<Integer, List<MenuVO>>();
        for (MenuVO menuVO : baseMenu) {
            baseMenuMappingChild.put(menuVO.getMenuId(), new ArrayList<MenuVO>());
        }
        
        // 循环将子菜单与父菜单对应成MAP列表
        for (MenuVO menuVO : childMenu) {
            if (baseMenuMappingChild.get(menuVO.getParentMenuId()) == null) {
                continue;
            }
            baseMenuMappingChild.get(menuVO.getParentMenuId()).add(menuVO);
        }
        
        // 循环组装父菜单对应的子菜单信息
        for (MenuVO menuVO : baseMenu) {
            menuVO.setChildMenuVOs(baseMenuMappingChild.get(menuVO.getMenuId()));
        }
        return baseMenu;
    }
    
    /**
     * 插入角色与菜单对应关系
     * 
     * @param roleVO 角色信息
     * @return 插入记录数
     */
    public int insertRoleMappingMenu(RoleVO roleVO) {
        int result = 0;
        try {
            
            // 删除此角色与菜单的关联信息
            SimpleCondition menuCondition = new SimpleCondition();
            menuCondition.andEqual("roleId", roleVO.getRoleId());
            roleMapper.deleteRoleRMenu(menuCondition);
            
            // 删除此角色与操作权限的关联关系
            SimpleCondition roleCondition = new SimpleCondition();
            roleCondition = new SimpleCondition();
            roleCondition.andEqual("roleId", roleVO.getRoleId());
            roleMapper.deleteRoleROperation(roleCondition);
            
            if (roleVO.getOperationId().length() > 0) {
                List<RoleRMenuVO> roleRMenuVOs = new ArrayList<RoleRMenuVO>();
                String[] operationIds = roleVO.getOperationId().split(",");
                StringBuffer sbOperationId = new StringBuffer();
                String[] operationIdStr = null;
                List<RoleROperationVO> roleROperationVOs = new ArrayList<RoleROperationVO>();
                for (String operationId : operationIds) {
                    operationIdStr = operationId.split("-");
                    sbOperationId.append(operationIdStr[0]).append(",");
                    if (!"null".equals(operationIdStr[0]) && Integer.parseInt(operationIdStr[0]) > 0) {
                        roleROperationVOs.add(new RoleROperationVO(roleVO.getRoleId(), Integer.parseInt(operationIdStr[0])));
                    } else {
                        roleRMenuVOs.add(new RoleRMenuVO(roleVO.getRoleId(), Integer.parseInt(operationIdStr[1])));
                    }
                }
                
                // 插入新的角色与操作关联关系
                if (roleROperationVOs.size() > 0) {
                    roleMapper.batchInsertRoleROperation(roleROperationVOs);
                    result = roleROperationVOs.size();
                }
                
                Map<String, String> param = new HashMap<String, String>();
                param.put("operationId", sbOperationId.substring(0, sbOperationId.length() - 1));
                List<String> menuIds = roleMapper.queryMenuIdByOperationId(param);
                for (String menuId : menuIds) {
                    roleRMenuVOs.add(new RoleRMenuVO(roleVO.getRoleId(), Integer.parseInt(menuId)));
                }
                // 插入新的角色与菜单关联信息
                if (roleRMenuVOs.size() > 0) {
                    roleMapper.batchInsertRoleRMenu(roleRMenuVOs);
                }
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
        return result;
    }
    
    /**
     * 删除角色及角色的关联关系
     * 
     * @param roleId 角色ID
     */
    public void deleteRoleAndRelation(int roleId) {
        SimpleCondition condition = new SimpleCondition();
        condition.andEqual("roleId", roleId);
        
        roleMapper.deleteRoleRMenu(condition);
        roleMapper.deleteRoleROperation(condition);
        roleMapper.deleteUserRRole(condition);
        roleMapper.delete(roleId);
    }
    
    /**
     * 新增角色与用户对应关系
     * 
     * @param roleVO 角色信息
     * @return 新增的记录数量
     */
    public int insertRoleMappingUser(RoleVO roleVO) {
        int result = 0;
        String userIds = roleVO.getUserId();
        if (userIds.endsWith(";")) {
            userIds = userIds.substring(0, userIds.length() - 1);
        }
        
        // 删除此角色与用户的关联信息(每次只删除当前部门对应的)
        Map<String, String> param = new HashMap<String, String>();
        param.put("roleId", String.valueOf(roleVO.getRoleId()));
        param.put("deptCode", roleVO.getDeptCode());
        roleMapper.deleteUserRRoleByDeptCode(param);
        
        if (userIds.length() > 0) {
            List<UserRRoleVO> userRRoleVOs = new ArrayList<UserRRoleVO>();
            for (String userId : userIds.split(";")) {
                userRRoleVOs.add(new UserRRoleVO(Integer.parseInt(userId), roleVO.getRoleId()));
            }
            roleMapper.batchInsertUserRRole(userRRoleVOs);
            result = userRRoleVOs.size();
        }
        return result;
    }
    
}
