
package com.lckj.security.role.model;

import com.lckj.base.model.PagerParam;

/**
 * 菜单角色关系实体类
 * 
 * @author 黄洪波
 * @since 1.0
 * @version 2015-05-24 黄洪波
 */
public class RoleRMenuVO extends PagerParam {
    
    /** 菜单ID **/
    private Integer menuId;
    
    /** 角色ID **/
    private Integer roleId;
    
    /**
     * 构造函数
     * 
     * @param roleId 角色ID
     * @param menuId 菜单ID
     */
    public RoleRMenuVO(Integer roleId, Integer menuId) {
        this.menuId = menuId;
        this.roleId = roleId;
    }
    
    /**
     * 获取菜单ID
     * 
     * @return 菜单ID
     */
    public Integer getMenuId() {
        return menuId;
    }
    
    /**
     * 设值菜单ID
     * 
     * @param menuId 菜单ID
     */
    public void setMenuId(Integer menuId) {
        this.menuId = menuId;
    }
    
    /**
     * 获取角色ID
     * 
     * @return 角色ID
     */
    public Integer getRoleId() {
        return roleId;
    }
    
    /**
     * 设值角色ID
     * 
     * @param roleId 角色ID
     */
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }
    
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(512);
        sb.append("RoleRMenuVO[");
        sb.append(super.toString());
        sb.append("\n    menuId=").append(this.menuId);
        sb.append("\n    roleId=").append(this.roleId);
        sb.append("\n]");
        return sb.toString();
    }
}
